# INF-433 · Unidad II-2 · Automatización de pruebas con Selenium, JUnit y Jenkins

Trabajo individual sobre un proyecto **preexistente de código abierto**:
**Spring PetClinic** (repositorio `spring-projects/spring-petclinic`, licencia Apache 2.0,
carpeta `spring-petclinic/` de este ZIP). Tiene interfaz web (Thymeleaf) y código Java con
reglas de negocio reales.

## Qué se añadió al proyecto original

| Archivo (dentro de `spring-petclinic/`) | Propósito |
|---|---|
| `src/test/java/.../qa/PetValidatorRulesTest.java` | **JUnit Jupiter**: 7 pruebas unitarias de la regla `PetValidator` (válido, límite, inválido). Sin navegador ni base de datos. |
| `src/test/java/.../qa/OwnerFlowSeleniumTest.java` | **Selenium WebDriver**: S-01 (alta de propietario válida) y S-02 (teléfono inválido). Spring Boot arranca la app solo, en un puerto aleatorio. |
| `src/test/java/.../qa/ScreenshotRecorder.java` | Guarda una captura PNG numerada por cada paso en `target/screenshots/<escenario>/`. |
| `Jenkinsfile` | Pipeline: Codigo, Entorno, Compilar, JUnit, Selenium, publicación de resultados. |
| `qa/jenkins/Dockerfile` | Jenkins con Chromium y su driver, para poder ejecutar Selenium en el agente. |
| `pom.xml` (modificado) | Dependencia `selenium-java` 4.51.0 (scope `test`) y filtro de etiquetas en Surefire. |

Casos: ver tabla de diseño en el informe (sección 2).

## Requisitos

- JDK 17 o superior (el proyecto exige 17; Jenkins del Dockerfile usa JDK 21).
- Google Chrome o Chromium instalado (solo para la suite Selenium).
- Acceso a Internet la primera vez (Maven descarga dependencias).
- No hace falta instalar Maven: se usa el wrapper (`mvnw` / `mvnw.cmd`).
- Docker, solo si se quiere Jenkins en contenedor.

## Ejecución local

Desde la carpeta `spring-petclinic/`. En Windows usar `mvnw.cmd` en lugar de `./mvnw`.

El `pom.xml` original valida el formato del código (`spring-javaformat`) y busca URLs
`http://` (`nohttp`) en la fase `validate`. Las pruebas de QA no dependen de esas
validaciones, por eso los comandos las omiten con `-Dspring-javaformat.skip=true
-Dcheckstyle.skip=true`. Para dejar el código con el formato del proyecto, ejecutar una vez
`./mvnw spring-javaformat:apply`.

**1. Pruebas unitarias (JUnit):**

```
./mvnw -B -Dspring-javaformat.skip=true -Dcheckstyle.skip=true test -Dtest=PetValidatorRulesTest
```

**2. Pruebas de interfaz (Selenium), sin ventana (modo headless):**

```
./mvnw -B -Dspring-javaformat.skip=true -Dcheckstyle.skip=true test -Dtest=OwnerFlowSeleniumTest -Dexcluded.groups=none
```

**3. Selenium con el navegador visible** (útil para las capturas E-03 a E-06):

```
./mvnw -B -Dspring-javaformat.skip=true -Dcheckstyle.skip=true test -Dtest=OwnerFlowSeleniumTest -Dexcluded.groups=none -Dselenium.headless=false
```

Si Chrome no está en la ruta estándar, definir `CHROME_BIN` (o `-Dchrome.bin=...`). Para usar
un chromedriver propio, definir `CHROMEDRIVER` (o `-Dwebdriver.chrome.driver=...`); si no se
define, Selenium Manager lo descarga.

Un `mvn test` normal **no** ejecuta Selenium (la etiqueta `selenium` está excluida por
defecto), así que no exige navegador.

**Resultados:** reportes en `target/surefire-reports/` (XML y TXT); capturas en
`target/screenshots/S-01-valid-owner/` y `target/screenshots/S-02-invalid-telephone/`.

## Jenkins con Docker

1. Subir la carpeta `spring-petclinic/` (con los cambios confirmados en una rama) a un
   repositorio Git propio, por ejemplo un fork en GitHub.
2. Construir y arrancar Jenkins (desde `spring-petclinic/`):

   ```
   docker build -t jenkins-qa qa/jenkins
   docker run -d --name jenkins-qa -p 8080:8080 -p 50000:50000 -v jenkins_qa_home:/var/jenkins_home jenkins-qa
   docker exec jenkins-qa cat /var/jenkins_home/secrets/initialAdminPassword
   ```

3. Abrir `http://localhost:8080`, pegar la contraseña inicial e instalar los plugins
   sugeridos (incluyen Pipeline, Git, JUnit y Timestamper).
4. Crear un trabajo **Pipeline** → *Pipeline script from SCM* → Git → URL del repositorio,
   rama, *Script Path* = `Jenkinsfile`.
5. Ejecutar **Build Now**. En la vista de etapas deben aparecer: Codigo, Entorno, Compilar,
   JUnit, Selenium. Los resultados quedan en *Test Result* y las capturas en *Build Artifacts*.

En un agente Windows el `Jenkinsfile` usa `bat` y `mvnw.cmd` automáticamente.

## Cómo obtener cada evidencia del informe

| Código | Evidencia | Cómo obtenerla |
|---|---|---|
| E-01 | Proyecto original y app en ejecución | IDE con el proyecto abierto; `./mvnw spring-boot:run` y abrir `http://localhost:8080` |
| E-02 | Código Selenium | Captura de `OwnerFlowSeleniumTest.java` (localizadores, datos, acciones, aserciones) |
| E-03 | Estado previo | `target/screenshots/S-01-valid-owner/01-precondition-owner-not-found.png` |
| E-04 | Interacción automatizada | `.../S-01-valid-owner/03-form-filled.png` |
| E-05 | Resultado positivo | `.../S-01-valid-owner/04-owner-created.png` y `05-owner-found-by-search.png` |
| E-06 | Escenario negativo | `.../S-02-invalid-telephone/03-validation-error.png` y `04-owner-not-stored.png` |
| E-07 | JUnit | Captura de `PetValidatorRulesTest.java` y de la salida de `mvn test` (Tests run) |
| E-08 | Jenkinsfile y trabajo | Captura del archivo y de *Configure* del trabajo |
| E-09 | Pipeline | Vista de etapas y *Console Output* de ambas suites |
| E-10 | Reportes en Jenkins | Página *Test Result* de la ejecución |

## Autenticidad

Las capturas y los resultados del informe deben salir de la ejecución real de este mismo
proyecto en el equipo del estudiante. No se incluyen contraseñas, tokens ni datos personales
reales: los datos de prueba son ficticios y la base de datos es H2 en memoria.

## Sin instalar nada: obtener las capturas reales con GitHub Actions

Si no tienes JDK ni Chrome, GitHub puede ejecutar las pruebas por ti:

1. Crea un repositorio en GitHub y sube el contenido de `spring-petclinic/` (incluida la carpeta `.github`).
2. Abre la pestaña **Actions** → workflow **qa-tests** (se ejecuta solo con cada push, o con *Run workflow*).
3. Al terminar, entra a la ejecución: la pantalla del resumen y el log de cada paso sirven como evidencias E-05/E-07/E-09 (líneas «Tests run»).
4. En la sección **Artifacts** descarga `evidencias`: contiene las capturas PNG de cada paso (E-03 a E-06) y los reportes.

Para Jenkins (E-08 a E-10) hace falta un Jenkins real: lo más simple sin instalar nada es un
GitHub Codespace (ofrece Docker): `docker build -t jenkins-qa qa/jenkins` y seguir la sección «Jenkins con Docker».
